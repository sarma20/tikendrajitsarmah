import { useEffect, useState } from "react";
import { MotionConfig } from "framer-motion";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import About from "./components/About";
import Skills from "./components/Skills";
import Projects from "./components/Projects";
import Experience from "./components/Experience";
import Contact from "./components/Contact";
import { profile } from "./data";

export default function App() {
  const [dark, setDark] = useState(() => {
    const saved = localStorage.getItem("theme");
    return saved ? saved === "dark" : window.matchMedia("(prefers-color-scheme: dark)").matches;
  });

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
    localStorage.setItem("theme", dark ? "dark" : "light");
  }, [dark]);

  return (
    <MotionConfig reducedMotion="user">
      <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
        <div className="absolute -left-32 top-0 h-96 w-96 rounded-full bg-river/30 blur-3xl dark:bg-river/20" />
        <div className="absolute -right-32 top-1/3 h-96 w-96 rounded-full bg-tea/30 blur-3xl dark:bg-tea/15" />
      </div>
      <Navbar dark={dark} toggle={() => setDark((d) => !d)} />
      <main>
        <Hero /><About /><Skills /><Projects /><Experience /><Contact />
      </main>
      <footer className="px-5 py-10 text-center text-sm">© {new Date().getFullYear()} {profile.name}</footer>
    </MotionConfig>
  );
}
