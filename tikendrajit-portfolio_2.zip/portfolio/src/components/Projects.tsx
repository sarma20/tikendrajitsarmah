import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Category, Project, projects } from "../data";
import { Chip, Section } from "./ui";

const filters: ("All" | Category)[] = ["All", "Full-Stack", "Analytics", "E-Commerce", "Productivity"];

export default function Projects() {
  const [filter, setFilter] = useState<"All" | Category>("All");
  const [active, setActive] = useState<Project | null>(null);
  const shown = projects.filter((p) => filter === "All" || p.category === filter);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setActive(null);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <Section id="projects" title="Projects">
      <div className="mb-8 flex flex-wrap gap-2" role="group" aria-label="Filter projects">
        {filters.map((f) => (
          <button key={f} onClick={() => setFilter(f)} aria-pressed={filter === f}
            className={`rounded-full px-4 py-1.5 text-sm font-medium transition ${filter === f ? "bg-slate-900 text-white dark:bg-tea dark:text-night" : "glass hover:bg-white/80 dark:hover:bg-white/10"}`}>
            {f}
          </button>
        ))}
      </div>

      <motion.div layout className="grid auto-rows-[190px] gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <AnimatePresence>
          {shown.map((p) => (
            <motion.button layout key={p.id} initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }}
              onClick={() => setActive(p)} whileHover={{ y: -4 }}
              className={`glass flex flex-col justify-between rounded-3xl p-6 text-left ${p.featured && filter === "All" ? "sm:col-span-2 lg:row-span-2" : ""}`}>
              <div>
                <Chip>{p.category}</Chip>
                <h3 className="mt-3 text-xl font-bold">{p.title}</h3>
                <p className="mt-2 text-sm leading-relaxed">{p.summary}</p>
              </div>
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400">{p.stack.join(", ")}</p>
            </motion.button>
          ))}
        </AnimatePresence>
      </motion.div>

      <AnimatePresence>
        {active && (
          <motion.div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setActive(null)}>
            <motion.div role="dialog" aria-modal="true" aria-label={active.title}
              initial={{ y: 30, scale: 0.96 }} animate={{ y: 0, scale: 1 }} exit={{ y: 30, scale: 0.96 }}
              onClick={(e) => e.stopPropagation()}
              className="glass w-full max-w-lg rounded-3xl bg-white/90 p-8 dark:bg-night/90">
              <Chip>{active.category}</Chip>
              <h3 className="mt-3 text-2xl font-bold">{active.title}</h3>
              <p className="mt-3 leading-relaxed">{active.details}</p>
              <ul className="mt-4 flex flex-wrap gap-2">{active.stack.map((s) => <li key={s}><Chip>{s}</Chip></li>)}</ul>
              <div className="mt-7 flex flex-wrap gap-3">
                <a href={active.live} target="_blank" rel="noreferrer" className="btn-primary">Live demo</a>
                <a href={active.github} target="_blank" rel="noreferrer" className="btn-glass">GitHub</a>
                <button onClick={() => setActive(null)} className="btn ml-auto">Close</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </Section>
  );
}
