import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { profile } from "../data";

export default function Hero() {
  const [i, setI] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setI((n) => (n + 1) % profile.roles.length), 2400);
    return () => clearInterval(t);
  }, []);

  return (
    <section id="top" className="mx-auto flex min-h-screen w-full max-w-6xl flex-col justify-center px-5 pt-24 sm:px-8">
      <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }} className="glass max-w-3xl rounded-3xl p-8 sm:p-12">
        <p className="mb-3 text-sm font-medium text-river-deep dark:text-river">{profile.location}</p>
        <h1 className="text-5xl font-extrabold leading-[1.02] tracking-tight sm:text-7xl">{profile.name}</h1>
        <div className="relative mt-4 h-9 overflow-hidden font-display text-xl font-semibold text-tea-deep dark:text-tea sm:text-2xl" aria-live="polite">
          <AnimatePresence mode="wait">
            <motion.span key={i} className="absolute" initial={{ y: 28, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: -28, opacity: 0 }} transition={{ duration: 0.35 }}>
              {profile.roles[i]}
            </motion.span>
          </AnimatePresence>
        </div>
        <p className="mt-5 max-w-xl text-base leading-relaxed sm:text-lg">{profile.bio}</p>
        <div className="mt-8 flex flex-wrap gap-3">
          <a href="#projects" className="btn-primary">View projects</a>
          <a href={profile.resume} download className="btn-glass">Download resume</a>
          <a href="#contact" className="btn-glass">Contact me</a>
        </div>
      </motion.div>
    </section>
  );
}
