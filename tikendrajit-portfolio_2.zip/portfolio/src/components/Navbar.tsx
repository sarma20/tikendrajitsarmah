const links = ["about", "skills", "projects", "experience", "contact"];

export default function Navbar({ dark, toggle }: { dark: boolean; toggle: () => void }) {
  return (
    <header className="fixed inset-x-0 top-3 z-40 flex justify-center px-3">
      <nav aria-label="Primary" className="glass flex w-full max-w-3xl items-center justify-between rounded-full px-4 py-2">
        <a href="#top" className="font-display text-sm font-bold text-slate-900 dark:text-white">TS</a>
        <ul className="hidden gap-5 text-sm font-medium sm:flex">
          {links.map((l) => (
            <li key={l}><a href={`#${l}`} className="capitalize transition hover:text-river-deep dark:hover:text-tea">{l}</a></li>
          ))}
        </ul>
        <button onClick={toggle} aria-label={dark ? "Switch to light mode" : "Switch to dark mode"}
          className="rounded-full px-3 py-1 text-sm font-medium transition hover:bg-black/5 dark:hover:bg-white/10">
          {dark ? "Light" : "Dark"}
        </button>
      </nav>
    </header>
  );
}
