import { FormEvent } from "react";
import { profile } from "../data";
import { Section } from "./ui";

export default function Contact() {
  const send = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const body = `${f.get("message")}\n\n— ${f.get("name")}`;
    window.location.href = `mailto:${profile.email}?subject=${encodeURIComponent("Portfolio inquiry")}&body=${encodeURIComponent(body)}`;
  };
  const field = "w-full rounded-xl border border-black/10 bg-white/70 px-4 py-3 text-sm dark:border-white/10 dark:bg-white/5";

  return (
    <Section id="contact" title="Get in touch">
      <div className="grid gap-6 md:grid-cols-2">
        <div className="glass rounded-3xl p-7">
          <ul className="space-y-4 text-sm">
            <li><a className="font-semibold hover:text-river-deep dark:hover:text-tea" href={`mailto:${profile.email}`}>{profile.email}</a></li>
            <li><a className="font-semibold hover:text-river-deep dark:hover:text-tea" href={`tel:+91${profile.phone}`}>{profile.phone}</a></li>
            <li>{profile.location}</li>
          </ul>
          <div className="mt-6 flex flex-wrap gap-3">
            <a href={profile.whatsapp} target="_blank" rel="noreferrer" className="btn-primary">Chat on WhatsApp</a>
            {profile.socials.map((s) => (
              <a key={s.label} href={s.href} target="_blank" rel="noreferrer" className="btn-glass">{s.label}</a>
            ))}
          </div>
        </div>
        <form onSubmit={send} className="glass space-y-4 rounded-3xl p-7">
          <label className="block text-sm font-medium">Your name<input name="name" required className={`${field} mt-1`} /></label>
          <label className="block text-sm font-medium">Message<textarea name="message" required rows={4} className={`${field} mt-1`} /></label>
          <button className="btn-primary">Send email</button>
        </form>
      </div>
    </Section>
  );
}
