import { credentials, experience } from "../data";
import { Section } from "./ui";

export default function Experience() {
  return (
    <Section id="experience" title="Experience & credentials">
      <div className="grid gap-6 md:grid-cols-3">
        <div className="glass rounded-3xl p-7 md:col-span-2">
          <h3 className="mb-5 text-xl font-bold">Experience</h3>
          <ol className="space-y-6 border-l border-tea/50 pl-5">
            {experience.map((e) => (
              <li key={e.title}>
                <p className="font-semibold text-slate-900 dark:text-white">{e.title}</p>
                <p className="mt-1 text-sm leading-relaxed">{e.text}</p>
              </li>
            ))}
          </ol>
        </div>
        <div className="glass rounded-3xl p-7">
          <h3 className="mb-5 text-xl font-bold">Certifications</h3>
          <ul className="space-y-3">
            {credentials.map((c) => (
              <li key={c} className="rounded-xl border border-black/5 bg-white/60 px-4 py-3 text-sm font-medium dark:border-white/10 dark:bg-white/5">{c}</li>
            ))}
          </ul>
        </div>
      </div>
    </Section>
  );
}
