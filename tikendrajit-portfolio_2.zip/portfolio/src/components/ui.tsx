import { ReactNode } from "react";

export function Section({ id, title, children }: { id: string; title: string; children: ReactNode }) {
  return (
    <section id={id} className="mx-auto w-full max-w-6xl scroll-mt-20 px-5 py-20 sm:px-8">
      <h2 className="mb-10 text-3xl font-bold tracking-tight sm:text-4xl">{title}</h2>
      {children}
    </section>
  );
}

export function Chip({ children }: { children: ReactNode }) {
  return <span className="rounded-full border border-river/30 bg-river/10 px-3 py-1 text-xs font-medium text-river-deep dark:text-river">{children}</span>;
}
