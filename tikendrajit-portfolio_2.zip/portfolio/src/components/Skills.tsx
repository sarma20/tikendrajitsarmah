import { motion } from "framer-motion";
import { skills } from "../data";
import { Section } from "./ui";

export default function Skills() {
  return (
    <Section id="skills" title="Skills & core technologies">
      <div className="grid gap-6 md:grid-cols-2">
        {skills.map((g) => (
          <div key={g.group} className="glass rounded-3xl p-7">
            <h3 className="mb-5 text-xl font-bold">{g.group}</h3>
            <ul className="flex flex-wrap gap-2.5">
              {g.items.map((s) => (
                <motion.li key={s} whileHover={{ scale: 1.06 }} className="rounded-xl border border-black/5 bg-white/60 px-4 py-2 text-sm font-medium dark:border-white/10 dark:bg-white/5">
                  {s}
                </motion.li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </Section>
  );
}
