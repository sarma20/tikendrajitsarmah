import { motion } from "framer-motion";
import { education, focus } from "../data";
import { Section } from "./ui";

export default function About() {
  return (
    <Section id="about" title="About & background">
      <div className="grid gap-6 md:grid-cols-5">
        <div className="glass rounded-3xl p-7 md:col-span-2">
          <h3 className="mb-5 text-xl font-bold">Education</h3>
          <ol className="space-y-5 border-l border-river/40 pl-5">
            {education.map((e) => (
              <li key={e.title}>
                <p className="font-semibold text-slate-900 dark:text-white">{e.title}</p>
                <p className="text-sm">{e.place}</p>
              </li>
            ))}
          </ol>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 md:col-span-3">
          {focus.map((f) => (
            <motion.div key={f.title} whileHover={{ y: -4 }} className="glass rounded-2xl p-5">
              <h3 className="text-base font-bold">{f.title}</h3>
              <p className="mt-2 text-sm leading-relaxed">{f.text}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </Section>
  );
}
