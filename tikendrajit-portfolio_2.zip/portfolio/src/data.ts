export const profile = {
  name: "Tikendrajit Sarmah",
  roles: ["Full-Stack Engineer", "UI/UX Designer", "Software Architect", "Creative Technologist"],
  bio: "A creative full-stack engineer dedicated to crafting premium, fast, and highly-polished digital products by bridging rigorous backend architecture with delightful visual design.",
  email: "tikendrajitsarmah386@gmail.com",
  phone: "9387192132",
  whatsapp: "https://wa.me/919387192132",
  location: "Mangaldai, Assam",
  resume: "/resume.pdf", // drop your PDF in /public/resume.pdf
  socials: [
    { label: "GitHub", href: "https://github.com/" },       // TODO: add your profile URL
    { label: "LinkedIn", href: "https://linkedin.com/" },   // TODO: add your profile URL
    { label: "Instagram", href: "https://instagram.com/" }, // TODO: add your profile URL
  ],
};

export const education = [
  { title: "Bachelor of Computer Application (BCA)", place: "Mangaldai College, Assam" },
  { title: "Higher Secondary (HS)", place: "Assam" },
  { title: "HSLC", place: "Assam" },
];

export const focus = [
  { title: "Clean interfaces", text: "Clear hierarchy and restrained visuals that make complex products easy to use." },
  { title: "Sub-100ms APIs", text: "Query tuning, indexing and caching so responses feel instant." },
  { title: "Pixel-perfect layouts", text: "Design-to-code fidelity across every screen size." },
  { title: "Inclusive design", text: "Keyboard, screen-reader and contrast-friendly by default." },
];

export const skills = [
  { group: "Frontend & UI/UX", items: ["HTML", "CSS", "JavaScript", "React", "Tailwind CSS", "Figma"] },
  { group: "Backend & Systems", items: ["Python", "Node.js", "Express", "PostgreSQL", "REST APIs", "GraphQL"] },
];

export type Category = "Full-Stack" | "Analytics" | "E-Commerce" | "Productivity";
export interface Project {
  id: string; title: string; category: Category; summary: string; details: string;
  stack: string[]; live: string; github: string; featured?: boolean;
}

// Placeholder projects: replace with your real work.
export const projects: Project[] = [
  { id: "p1", title: "Full-Stack Web App", category: "Full-Stack", featured: true,
    summary: "Production-style app with auth, REST API and a polished React front end.",
    details: "End-to-end build: React + Tailwind client, Node/Express API, PostgreSQL schema with indexed queries and JWT authentication.",
    stack: ["React", "Node.js", "Express", "PostgreSQL"], live: "#", github: "#" },
  { id: "p2", title: "Financial Analytics Dashboard", category: "Analytics",
    summary: "Interactive charts and KPIs for tracking spend and revenue.",
    details: "Dashboard with filterable time ranges, aggregated Postgres views and a Python service for data prep.",
    stack: ["React", "Python", "PostgreSQL"], live: "#", github: "#" },
  { id: "p3", title: "E-Commerce Framework", category: "E-Commerce",
    summary: "Reusable storefront foundation: catalogue, cart and checkout.",
    details: "Modular storefront with product search, cart state, order API and a GraphQL layer for flexible queries.",
    stack: ["React", "GraphQL", "Node.js"], live: "#", github: "#" },
  { id: "p4", title: "Task Management Tool", category: "Productivity",
    summary: "Fast, keyboard-friendly boards for small teams.",
    details: "Drag-and-drop boards, optimistic updates and a clean accessible UI designed in Figma first.",
    stack: ["React", "TypeScript", "Express"], live: "#", github: "#" },
];

export const experience = [
  { title: "Building modern web applications", text: "Shipping responsive React front ends backed by Node and Python services." },
  { title: "Optimizing database performance", text: "Profiling slow queries and tuning PostgreSQL to keep API responses fast." },
  { title: "Collaborating with design teams", text: "Turning Figma designs into accessible, pixel-accurate interfaces." },
];

export const credentials = ["AWS Certification", "Google UX Design Certificate"];
