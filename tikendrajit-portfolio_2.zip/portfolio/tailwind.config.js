/** @type {import('tailwindcss').Config} */
export default {
  darkMode: "class",
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Bricolage Grotesque"', "system-ui", "sans-serif"],
        sans: ["Inter", "system-ui", "sans-serif"],
      },
      colors: {
        tea: { DEFAULT: "#e2b04a", deep: "#b8801f" },
        river: { DEFAULT: "#2bb3a3", deep: "#0f766e" },
        night: "#07131a",
        mist: "#eef4f1",
      },
    },
  },
  plugins: [],
};
